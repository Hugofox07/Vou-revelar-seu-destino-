# HTML
- HyperText Markup Language

- Hiper Texto?
- Marcação
  - tags
  - atributos
- Linguagem
  - maneira de escrever


https://gist.githubusercontent.com/maykbrito/0acdf4ce919838ffed50915a31fc5b23/raw/6f4dd01ec3116428ec4c99255944cb9ac7927590/cristal-ball.svg
